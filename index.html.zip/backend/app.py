from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Allow frontend to communicate with backend

# Static stock market data (Basic for now)
stocks = {
    "Reliance": {"price": 2500, "sector": "Energy"},
    "TCS": {"price": 3600, "sector": "IT"},
    "HDFC Bank": {"price": 1500, "sector": "Banking"}
}

# Third-party investment apps
investment_apps = [
    {"name": "Dream11", "link": "https://www.dream11.com"},
    {"name": "Ludo Empire", "link": "https://www.ludoempire.com"},
    {"name": "Upstox", "link": "https://upstox.com"},
    {"name": "Zerodha", "link": "https://zerodha.com"}
]

@app.route("/suggest", methods=["POST"])
def suggest():
    data = request.json
    amount = data.get("amount", 0)

    # Basic investment suggestion logic
    if amount < 500:
        suggestion = "You can invest in small games like Ludo Empire or Dream11."
    elif amount < 2000:
        suggestion = "Consider investing in mutual funds or beginner stocks like HDFC Bank."
    else:
        suggestion = "You can invest in big stocks like Reliance or TCS for better returns."

    return jsonify({"suggestion": suggestion, "stocks": stocks, "apps": investment_apps})

if __name__ == "__main__":
    app.run(debug=True)
